
const bcrypt = require('bcrypt')
const db = require("../models/db_model")
const Mentor = db.mentor;
const Op = db.Sequelize.Op;


exports.create = async (req, res) => {

    // Adding area of interest for Mentor
    const mentor = {
        user_id: req.body.user_id,
        aoi: req.body.area_of_interest,
        exp_years: req.body.exp_years,
    };

  
    // Save Mentor in the database
    Mentor.create(mentor)
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                err.name || "Some error occurred while creating the Mentor."
            });
        });
};

exports.findOne = (req, res) => {
    const id = req.params.id;
  
    Mentor.findByPk(id)
        .then(data => {
            if(data == null) res.status(404).send("mentor with given id not found")
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message: "Error retrieving Mentor with id=" + id
            });
        });
};

exports.findAll = (req, res) => {
    const name = req.query.name;
    var condition = name ? { name: { [Op.like]: `%${name}%` } } : null;
  
    Mentor.findAll({ where: condition })
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Mentors."
        });
    });
};

exports.update = (req, res) => {
    const id = req.params.id;

    Mentor.update(req.body, {
        where: { id: id }
    })

    .then(num => {
        if (num == 1) {
            res.send({
                message: "Mentor was updated successfully."
            });
        } else {
            res.send({
                message: `Cannot update Mentor with id=${id}. Maybe Mentor was not found or req.body is empty!`
            });
        }
    })
    .catch(err => {
        res.status(500).send({
            message: "Error updating Mentor with id=" + id
        });
    });
};

exports.delete = (req, res) => {
    const id = req.params.id;
  
    Mentor.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                message: "Mentor was deleted successfully!"
            });
            } else {
                res.send({
                    message: `Cannot delete Mentor with id=${id}. Maybe Mentor was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Mentor with id=" + id
            });
    });
};

exports.deleteAll = (req, res) => {
    Mentor.destroy({
        where: {},
        truncate: false
    })
        .then(nums => {
            res.send({ message: `${nums} Mentors were deleted successfully!` });
        })
        .catch(err => {
            res.status(500).send({
            message:
                err.message || "Some error occurred while removing all Mentors."
            });
        });
};
