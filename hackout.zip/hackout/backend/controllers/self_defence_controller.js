
const db = require("../models/db_model")
const SelfDefence = db.selfDefence;
const Op = db.Sequelize.Op;


exports.create = async (req, res) => {

    // Adding area of interest for Self defence
    const selfDefence = {
        u_id: req.body.user_id,
        m_id: req.body.mentor_id
    };

  
    // Save SelfDefence in the database
    SelfDefence.create(mentor)
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                err.name || "Some error occurred while creating the SelfDefence."
            });
        });
};

exports.findOne = (req, res) => {
    const id = req.params.id;
  
    SelfDefence.findByPk(id)
        .then(data => {
            if(data == null) res.status(404).send("self defence with given id not found")
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message: "Error retrieving self defence with id=" + id
            });
        });
};

exports.findAll = (req, res) => {
    const name = req.query.name;
    var condition = name ? { name: { [Op.like]: `%${name}%` } } : null;
  
    SelfDefence.findAll({ where: condition })
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving self defence."
        });
    });
};

exports.update = (req, res) => {
    const id = req.params.id;

    SelfDefence.update(req.body, {
        where: { id: id }
    })

    .then(num => {
        if (num == 1) {
            res.send({
                message: "Self defence was updated successfully."
            });
        } else {
            res.send({
                message: `Cannot update Self defence with id=${id}. Maybe Self defence was not found or req.body is empty!`
            });
        }
    })
    .catch(err => {
        res.status(500).send({
            message: "Error updating SelfDefence with id=" + id
        });
    });
};

exports.delete = (req, res) => {
    const id = req.params.id;
  
    SelfDefence.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                message: "Self defence was deleted successfully!"
            });
            } else {
                res.send({
                    message: `Cannot delete Self defence with id=${id}. Maybe Self defence was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete Self defence with id=" + id
            });
    });
};

exports.deleteAll = (req, res) => {
    SelfDefence.destroy({
        where: {},
        truncate: false
    })
        .then(nums => {
            res.send({ message: `${nums} Self Defences were deleted successfully!` });
        })
        .catch(err => {
            res.status(500).send({
            message:
                err.message || "Some error occurred while removing all Self Defences."
            });
        });
};
