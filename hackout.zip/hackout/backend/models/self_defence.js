'use strict';
const Joi = require('joi');
const {
  Model
} = require('sequelize');
exports.selfDefence = (sequelize, DataTypes) => {
  class SelfDefence extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  SelfDefence.init({
    u_id: DataTypes.INTEGER,
    m_id: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'SelfDefence',
  });
  return SelfDefence;
};

exports.validate = function validateSelfDefence(selfDefence) {

  const schema = Joi.object({
    u_id: Joi.int().required(),
    m_id: Joi.int().required()
  });
  return schema.validate(selfDefence);
}