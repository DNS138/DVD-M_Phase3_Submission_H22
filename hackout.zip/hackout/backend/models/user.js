'use strict';
const {
  Model
} = require('sequelize');
exports.user = (sequelize, DataTypes) => {
  class User extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Mentor.belongsTo(models.User, {
        foreignKey: "u_id",
      })
    }
  };
  User.init({
    type: DataTypes.BOOLEAN,
    first_name: DataTypes.STRING,
    last_name: DataTypes.STRING,
    email: DataTypes.STRING,
    password: DataTypes.STRING,
    dob: DataTypes.DATE,
    aadhar_number: DataTypes.STRING,
    education: DataTypes.STRING,
    emp_status: DataTypes.BOOLEAN,
    domicile: DataTypes.STRING,
    address: DataTypes.STRING,
    contact_number: DataTypes.STRING,
    city: DataTypes.STRING,
    state: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'User',
  });
  return User;
};

exports.validate = function validateUser(user) {

  const schema = Joi.object({
      first_name: Joi.string().min(2).max(50).required(),
      last_name: Joi.string().min(2).max(50).required(),
      email: Joi.string().min(5).max(255).required().email(),
      password: Joi.string().min(5).max(255),
      dob: Joi.date().required(),
      aadhar_number: Joi.string().min(15).max(15).required(),
      type: Joi.boolean().required(),
      education: Joi.string().min(5).max(255).required(),
      emp_status: Joi.boolean().required(),
      domicile: Joi.string().min(5).max(255).required(),
      address: Joi.string().min(5).max(255).required(),
      contact_number: Joi.string().min(10).max(15).required(),
      city: Joi.string().min(5).max(255).required(),
      state: Joi.string().min(5).max(255).required()
  });
  return schema.validate(user);
}