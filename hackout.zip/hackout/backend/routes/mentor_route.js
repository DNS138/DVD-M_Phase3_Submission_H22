
const { validate } = require('../models/mentor');
const validate_mid = require('../middleware/validate');
const validateEmail = require('../middleware/validateEmail');


module.exports = function(app) {
    const mentor = require("../controllers/mentor_controller");
  
    var router = require("express").Router();
  

    // Create a new Tutorial
    router.get("/:id", (mentor.findOne));
    router.get("/", (mentor.findAll));
    router.post("/",[validateEmail,validate_mid(validate)], mentor.create);
    router.put("/:id",validate_mid(validate), (mentor.update));
    router.delete("/:id", (mentor.delete));
    router.delete("/", (mentor.deleteAll));
 
    app.use('/api/mentors', router);
};