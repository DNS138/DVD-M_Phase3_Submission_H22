// export const WEATHER_API_BASEURL= "https://api.ambeedata.com/weather/latest"

// export const SOIL_API_BASEURL="https://api.ambeedata.com/soil/latest"

// export const AIR_API_BASEURL="https://api.ambeedata.com/latest"

// export const AMBEE_API_KEY="jr1SKlUSrE5C3zgkhq2iR3a5Kz9ekAtE15TCMK9X"

// export const POLLEN_API_BASEURL="https://api.ambeedata.com/latest/pollen"

// export const WATERVAPOR_API_BASEURL="https://api.ambeedata.com/waterVapor/latest"