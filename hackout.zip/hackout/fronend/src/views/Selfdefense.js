import React from 'react'

const Selfdefense = () => {
  return (
    <div>Selfdefense</div>
  )
}

export default Selfdefense