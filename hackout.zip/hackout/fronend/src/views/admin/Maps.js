import React, { useState } from "react";

// components

import MapExample from "components/Maps/MapExample.js";

export default function Maps() {
  //lat ,long
  const [lat, setLat] = useState(null);
  const [long, setLong] = useState(null);
  const [add, setAdd] = useState("");

  const Lat=lat
  const Long=long
  const map=`https://openlandmap.org/#/?base=OpenStreetMap%20(grayscale)&center=${Lat},${Long}&zoom=2.8111550253555033&opacity=80&layer=lcv_land.cover_esacci.lc.l4_c&time=2018`

  function getLocation() {
    //get geolocation
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition, showError);

    } else {
      alert("Geolocation is not supported by this browser.");
    }
  }
  function showPosition(position) {
    console.log(position.coords);
    //set lat and long to state variable
    setLat(position.coords.latitude.toFixed(5));
    setLong(position.coords.longitude.toFixed(5));
    setAdd(`Location Submitted, Thank you to submit a location${Lat},${Long}`)
  }
  function showError(error) {
    //errors
    switch (error.code) {
      case error.PERMISSION_DENIED:
        alert("User denied the request for Geolocation.");
        break;
      case error.POSITION_UNAVAILABLE:
        alert("Location information is unavailable.");
        break;
      case error.TIMEOUT:
        alert("The request to get user location timed out.");
        break;
      case error.UNKNOWN_ERROR:
        alert("An unknown error occurred.");
        break;
    }
  }
  return (
    <>
      <div className="flex flex-wrap">
        <div className="w-full px-4 m-5">

          <div className="w-full px-4 shadow-lg rounded bg-white relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">
            <div className="w-full text-center lg:w-8/12 container mx-auto">
              <p className="text-4xl text-center">
                <br />
                <span role="img" aria-label="love">
                  🗺️
                </span>
              </p>
              <br />
              <h3 className="font-semibold text-3xl">
                Submit YourLocation
              </h3>
              <p className="text-blueGray-500 text-lg leading-relaxed mt-4 mb-4">
                turn on your GPS and submit the location!
              </p>
              <div className="sm:block flex flex-col mt-10">
                <button
                  onClick={getLocation}
                  className="get-started text-white font-bold px-6 py-4 rounded outline-none focus:outline-none mr-1 mb-2 bg-lightBlue-500 active:bg-lightBlue-600 uppercase text-sm shadow hover:shadow-lg ease-linear transition-all duration-150"
                >
                  Submit Location
                </button>

              </div>

              <div className="text-center mt-16">{add}</div>
              <br />
            </div>
          </div>
          <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">
            {/* <MapExample defaultCenter={defaultCenter}/> */}
            <section className="pt-20 pb-48">
              <iframe width="100%" height="500" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src={map}></iframe>
            </section>
          </div>
        </div>

      </div>
    </>
  );
}
