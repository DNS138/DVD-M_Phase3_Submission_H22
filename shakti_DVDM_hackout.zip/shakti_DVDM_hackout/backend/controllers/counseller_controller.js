
const db = require("../models/db_model")
const Counseller = db.counseller;
const Op = db.Sequelize.Op;


exports.create = async (req, res) => {

    // Adding area of interest for counselling entry
    const counseller = {
        u_id: req.body.u_id,
        m_id: req.body.m_id
    };

  
    // Save counseller in the database
    Counseller.create(counseller)
        .then(data => {
            res.send(data)
        })
        .catch(err => {
            res.status(500).send({
                message:
                err.name || "Some error occurred while creating the Counseller."
            });
        });
};

exports.findOne = (req, res) => {
    const id = req.params.id;
  
    Counseller.findByPk(id)
        .then(data => {
            if(data == null) res.status(404).send("counselling entry with given id not found")
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message: "Error retrieving counselling entry with id=" + id
            });
        });
};

exports.findAll = (req, res) => {
    const name = req.query.name;
    var condition = name ? { name: { [Op.like]: `%${name}%` } } : null;
  
    Counseller.findAll({ where: condition })
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving counselling entry."
        });
    });
};

exports.update = (req, res) => {
    const id = req.params.id;

    Counseller.update(req.body, {
        where: { id: id }
    })

    .then(num => {
        if (num == 1) {
            res.send({
                message: "counselling entry was updated successfully."
            });
        } else {
            res.send({
                message: `Cannot update counselling entry with id=${id}. Maybe counselling entry was not found or req.body is empty!`
            });
        }
    })
    .catch(err => {
        res.status(500).send({
            message: "Error updating Counseller with id=" + id
        });
    });
};

exports.delete = (req, res) => {
    const id = req.params.id;
  
    Counseller.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                message: "counselling entry was deleted successfully!"
            });
            } else {
                res.send({
                    message: `Cannot delete counselling entry with id=${id}. Maybe counselling entry was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete counselling entry with id=" + id
            });
    });
};

exports.deleteAll = (req, res) => {
    Counseller.destroy({
        where: {},
        truncate: false
    })
        .then(nums => {
            res.send({ message: `${nums} counselling entries were deleted successfully!` });
        })
        .catch(err => {
            res.status(500).send({
            message:
                err.message || "Some error occurred while removing all counselling entries."
            });
        });
};
