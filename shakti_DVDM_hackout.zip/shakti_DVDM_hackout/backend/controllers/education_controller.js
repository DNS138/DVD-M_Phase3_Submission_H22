
const db = require("../models/db_model")
const Education = db.education;
const Op = db.Sequelize.Op;


exports.create = async (req, res) => {

    // Adding area of interest for education entry
    const education = {
        u_id: req.body.u_id,
        m_id: req.body.m_id,
        subject: req.body.subject
    };

  
    // Save education in the database
    Education.create(education)
        .then(data => {
            res.send(data)
        })
        .catch(err => {
            res.status(500).send({
                message:
                err.name || "Some error occurred while creating the Education."
            });
        });
};

exports.findOne = (req, res) => {
    const id = req.params.id;
  
    Education.findByPk(id)
        .then(data => {
            if(data == null) res.status(404).send("education entry with given id not found")
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message: "Error retrieving education entry with id=" + id
            });
        });
};

exports.findAll = (req, res) => {
    const name = req.query.name;
    var condition = name ? { name: { [Op.like]: `%${name}%` } } : null;
  
    Education.findAll({ where: condition })
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving education entry."
        });
    });
};

exports.update = (req, res) => {
    const id = req.params.id;

    Education.update(req.body, {
        where: { id: id }
    })

    .then(num => {
        if (num == 1) {
            res.send({
                message: "education entry was updated successfully."
            });
        } else {
            res.send({
                message: `Cannot update education entry with id=${id}. Maybe education entry was not found or req.body is empty!`
            });
        }
    })
    .catch(err => {
        res.status(500).send({
            message: "Error updating Education with id=" + id
        });
    });
};

exports.delete = (req, res) => {
    const id = req.params.id;
  
    Education.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                message: "education entry was deleted successfully!"
            });
            } else {
                res.send({
                    message: `Cannot delete education entry with id=${id}. Maybe education entry was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete education entry with id=" + id
            });
    });
};

exports.deleteAll = (req, res) => {
    Education.destroy({
        where: {},
        truncate: false
    })
        .then(nums => {
            res.send({ message: `${nums} education entries were deleted successfully!` });
        })
        .catch(err => {
            res.status(500).send({
            message:
                err.message || "Some error occurred while removing all education entries."
            });
        });
};
