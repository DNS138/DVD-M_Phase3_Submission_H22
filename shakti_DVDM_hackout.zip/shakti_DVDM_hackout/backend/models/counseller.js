'use strict';
const Joi = require('joi');
const {
  Model
} = require('sequelize');
exports.counseller = (sequelize, DataTypes) => {
  class Counseller extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  Counseller.init({
    u_id: DataTypes.INTEGER,
    m_id: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Counseller',
  });
  return Counseller;
};

exports.validate = function validateCounseller(counseller) {

  const schema = Joi.object({
    u_id: Joi.number().integer().required(),
    m_id: Joi.number().integer().required()
  });
  return schema.validate(counseller);
}