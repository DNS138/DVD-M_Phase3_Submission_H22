'use strict';
const Joi = require('joi');
const {
  Model
} = require('sequelize');
exports.education = (sequelize, DataTypes) => {
  class Education extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  Education.init({
    u_id: DataTypes.INTEGER,
    m_id: DataTypes.INTEGER,
    subject: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Education',
  });
  return Education;
};

exports.validate = function validateEducation(education) {

  const schema = Joi.object({
    u_id: Joi.number().integer().required(),
    m_id: Joi.number().integer().required(),
    subject: Joi.string().required()
  });
  return schema.validate(education);
}