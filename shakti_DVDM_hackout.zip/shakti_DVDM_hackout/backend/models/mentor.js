'use strict';
const Joi = require('joi');
const {
  Model
} = require('sequelize');
exports.mentor = (sequelize, DataTypes) => {
  class Mentor extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  };
  Mentor.init({
    u_id: DataTypes.INTEGER,
    aoi: DataTypes.STRING,
    exp_years: DataTypes.INTEGER,
  }, {
    sequelize,
    modelName: 'Mentor',
  });
  return Mentor;
};

exports.validate = function validateMentor(mentor) {

  const schema = Joi.object({
    u_id: Joi.number().integer().required(),
    aoi: Joi.string().required(),
    exp_years: Joi.number().integer().min(1).required(),
  });
  return schema.validate(mentor);
}