
const { validate } = require('../models/counseller');
const validate_mid = require('../middleware/validate');


module.exports = function(app) {
    const counseller = require("../controllers/counseller_controller");
  
    var router = require("express").Router();
  

    // Create a new Tutorial
    router.get("/:id", (counseller.findOne));
    router.get("/", (counseller.findAll));
    router.post("/",validate_mid(validate), counseller.create);
    router.put("/:id",validate_mid(validate), (counseller.update));
    router.delete("/:id", (counseller.delete));
    router.delete("/", (counseller.deleteAll));
 
    app.use('/api/counsellers', router);
};