
const { validate } = require('../models/education');
const validate_mid = require('../middleware/validate');


module.exports = function(app) {
    const education = require("../controllers/education_controller");
  
    var router = require("express").Router();
  

    // Create a new Tutorial
    router.get("/:id", (education.findOne));
    router.get("/", (education.findAll));
    router.post("/",validate_mid(validate), education.create);
    router.put("/:id",validate_mid(validate), (education.update));
    router.delete("/:id", (education.delete));
    router.delete("/", (education.deleteAll));
 
    app.use('/api/education', router);
};