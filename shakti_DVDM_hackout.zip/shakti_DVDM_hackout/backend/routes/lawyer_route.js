
const { validate } = require('../models/lawyer');
const validate_mid = require('../middleware/validate');


module.exports = function(app) {
    const lawyer = require("../controllers/lawyer_controller");
  
    var router = require("express").Router();
  

    // Create a new Tutorial
    router.get("/:id", (lawyer.findOne));
    router.get("/", (lawyer.findAll));
    router.post("/",validate_mid(validate), lawyer.create);
    router.put("/:id",validate_mid(validate), (lawyer.update));
    router.delete("/:id", (lawyer.delete));
    router.delete("/", (lawyer.deleteAll));
 
    app.use('/api/lawyers', router);
};