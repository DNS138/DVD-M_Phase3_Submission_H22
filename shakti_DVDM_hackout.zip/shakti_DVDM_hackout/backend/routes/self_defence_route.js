
const { validate } = require('../models/self_defence');
const validate_mid = require('../middleware/validate');

module.exports = function(app) {
    const selfDefence = require("../controllers/self_defence_controller");
  
    var router = require("express").Router();
  

    // Create a new Tutorial
    router.get("/:id", (selfDefence.findOne));
    router.get("/", (selfDefence.findAll));
    router.put("/:id",validate_mid(validate), (selfDefence.update));
    router.delete("/:id", (selfDefence.delete));
    router.delete("/", (selfDefence.deleteAll));
 
    app.use('/api/selfDefence', router);
};