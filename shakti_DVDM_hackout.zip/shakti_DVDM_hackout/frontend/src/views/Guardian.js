import React from 'react'

const Guardian = () => {
  return (
    <div>Guardian</div>
  )
}

export default Guardian