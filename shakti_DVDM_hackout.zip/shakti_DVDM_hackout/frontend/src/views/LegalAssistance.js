import React from 'react'

const LegalAssistance = () => {
  return (
    <div>LegalAssistance</div>
  )
}

export default LegalAssistance