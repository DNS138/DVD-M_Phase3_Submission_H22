import pandas as pd
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
import numpy as np
import string
from sklearn.feature_extraction.text import TfidfVectorizer
import os
import pickle

tokens = []
stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()
table = str.maketrans('', '', string.punctuation)
# print(table)
df=pd.read_csv('F:/Hackout_22/Shakti_datasets/courses.csv')
df=df.dropna()
desc=df['course_description']
for i in desc:
    token = word_tokenize(i)
    words = pd.Series(token).str.lower()
    words = [w.translate(table) for w in words]
    words = [w for w in words if w.lower() not in stop_words]
    words = [w for w in words if w.isalpha()]
    words = [lemmatizer.lemmatize(word) for word in words]
    text = ' '.join(words)
    tokens.append(text)
pre_processed = np.array(tokens)
vectorizer = TfidfVectorizer()
vect_desc = vectorizer.fit_transform(pre_processed).toarray()
pickle.dump(vectorizer, open(os.path.join(os.getcwd(), "vectorizer.pickle"), "wb"))

